import javax.swing.*;
import java.awt.*;

public class Bresenhams extends JFrame {

    int centerX, centerY, dGrid = 1, maxX, maxY;

    public Bresenhams() {
        setTitle("Bresenham's Line and Circle Drawing");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    void initgr() {
        Dimension d = getSize();
        maxX = d.width - 1;
        maxY = d.height - 1;
        centerX = maxX / 2;
        centerY = maxY / 2;
    }

    void drawLine(Graphics g, int x0, int y0, int x1, int y1) {
        int dx, dy, p, x, y;

        dx = Math.abs(x1 - x0);
        dy = Math.abs(y1 - y0);

        int sx = x0 < x1 ? 1 : -1;
        int sy = y0 < y1 ? 1 : -1;

        x = x0;
        y = y0;

        p = 2 * dy - dx;

        while (x != x1 || y != y1) {
            g.fillOval(x, y, 5, 5);

            int p2 = p * 2;

            if (p2 > -dx) {
                p -= 2 * dx;
                y += sy;
            }
            if (p2 < dy) {
                p += 2 * dy;
                x += sx;
            }
        }
    }

    void drawCircle(Graphics g, int x0, int y0, int radius) {
        int x = radius;
        int y = 0;
        int decision = 1 - x;

        while (y <= x) {
            drawCirclePoints(g, x0, y0, x, y);
            y++;

            if (decision <= 0) {
                decision += 2 * y + 1;
            } else {
                x--;
                decision += 2 * (y - x) + 1;
            }
            drawCirclePoints(g, x0, y0, x, y);
        }
    }

    void drawCirclePoints(Graphics g, int x0, int y0, int x, int y) {
        g.fillOval(x0 + x, y0 + y, 5, 5);
        g.fillOval(x0 - x, y0 + y, 5, 5);
        g.fillOval(x0 + x, y0 - y, 5, 5);
        g.fillOval(x0 - x, y0 - y, 5, 5);
        g.fillOval(x0 + y, y0 + x, 5, 5);
        g.fillOval(x0 - y, y0 + x, 5, 5);
        g.fillOval(x0 + y, y0 - x, 5, 5);
        g.fillOval(x0 - y, y0 - x, 5, 5);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        initgr();

        // Square
        drawLine(g, centerX - 100, centerY + 100, centerX + 100, centerY + 100);
        drawLine(g, centerX + 100, centerY + 100, centerX + 100, centerY - 100);
        drawLine(g, centerX + 100, centerY - 100, centerX - 100, centerY - 100);
        drawLine(g, centerX - 100, centerY - 100, centerX - 100, centerY + 100);

        // Triangle
        drawLine(g, centerX - 100, centerY + 100, centerX + 100, centerY + 100);
        drawLine(g, centerX + 100, centerY + 100, centerX + 0, centerY - 100);
        drawLine(g, centerX + 0, centerY - 100, centerX - 100, centerY + 100);

        // Circle
        drawCircle(g, centerX, centerY, 45);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Bresenhams bresenhams = new Bresenhams();
            bresenhams.setVisible(true);
        });
    }
}
