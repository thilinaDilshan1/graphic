public class ScalingAlgorithm {

    public static void main(String[] args) {
        int[] x = {50, 100, 100, 50};
        int[] y = {50, 50, 100, 100};

        // Original square
        System.out.println("Original Square:");
        printCoordinates(x, y);

        // Scaling by a factor of 2 in x and y
        scale(x, y, 2, 2);

        // Scaled square
        System.out.println("Scaled Square:");
        printCoordinates(x, y);
    }

    public static void scale(int x[], int y[], int sx, int sy) {
        for (int i = 0; i < x.length; i++) {
            x[i] = x[i] * sx;
            y[i] = y[i] * sy;
        }
    }

    public static void printCoordinates(int x[], int y[]) {
        for (int i = 0; i < x.length; i++) {
            System.out.println("Point " + (i + 1) + ": (" + x[i] + ", " + y[i] + ")");
        }
        System.out.println();
    }
}
