public class Translation {

    public static void main(String[] args) {
        int[][] rectangle = {
            {50, 50},   // Vertex 1 (x, y)
            {100, 50},  // Vertex 2
            {100, 100}, // Vertex 3
            {50, 100}   // Vertex 4
        };

        int[] translationVector = {30, 20}; // Translate by (30, 20)

        System.out.println("Original Rectangle:");
        printRectangle(rectangle);

        translateRectangle(rectangle, translationVector);

        System.out.println("Translated Rectangle:");
        printRectangle(rectangle);
    }

    public static void translateRectangle(int P[][], int T[]) {
        for (int i = 0; i < P.length; i++) {
            P[i][0] += T[0]; // Translate x-coordinate
            P[i][1] += T[1]; // Translate y-coordinate
        }
    }

    public static void printRectangle(int P[][]) {
        for (int i = 0; i < P.length; i++) {
            System.out.println("Vertex " + (i + 1) + ": (" + P[i][0] + ", " + P[i][1] + ")");
        }
        System.out.println();
    }
}
