import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;

public class Transform extends JFrame {
    private int centerX, centerY, maxX, maxY;

    public Transform() {
        setTitle("Transform");
        setSize(800, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set up the drawing panel
        DrawingPanel drawingPanel = new DrawingPanel();
        add(drawingPanel);

        // Center the frame on the screen
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((screenSize.width - getWidth()) / 2, (screenSize.height - getHeight()) / 2);
    }

    class DrawingPanel extends JPanel {
        public DrawingPanel() {
            setPreferredSize(new Dimension(400, 400));
        }

        private void initgr() {
            Dimension d = getSize();
            maxX = d.width - 1;
            maxY = d.height - 1;
            centerX = maxX / 2;
            centerY = maxY / 2;
        }

        private void drawLine(Graphics g, int x1, int y1, int x2, int y2) {
            g.drawLine(x1, y1, x2, y2);
        }

        private void drawTransformedRectangle(Graphics g, int x, int y, int width, int height, AffineTransform transform) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.transform(transform);

            drawLine(g2d, x, y, x + width, y);
            drawLine(g2d, x + width, y, x + width, y + height);
            drawLine(g2d, x + width, y + height, x, y + height);
            drawLine(g2d, x, y + height, x, y);

            g2d.dispose();
        }

        private void drawRegularPolygon(Graphics g, int x, int y, int sides, int size, AffineTransform transform) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.transform(transform);

            int[] xPoints = new int[sides];
            int[] yPoints = new int[sides];

            double angleIncrement = 2 * Math.PI / sides;

            for (int i = 0; i < sides; i++) {
                xPoints[i] = x + (int) (size * Math.cos(i * angleIncrement));
                yPoints[i] = y + (int) (size * Math.sin(i * angleIncrement));
            }

            g2d.drawPolygon(xPoints, yPoints, sides);
            g2d.dispose();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            initgr();

            // Draw the original rectangle
            drawLine(g, centerX - 100, centerY + 100, centerX + 100, centerY + 100);
            drawLine(g, centerX + 100, centerY + 100, centerX + 100, centerY - 100);
            drawLine(g, centerX + 100, centerY - 100, centerX - 100, centerY - 100);
            drawLine(g, centerX - 100, centerY - 100, centerX - 100, centerY + 100);

            // Customize scaling factor, translate amount, and rotate amount
            double scaleX = 1;  // Scaling factor along the x-axis
            double scaleY = 1;  // Scaling factor along the y-axis
            int translateX = 50; // Translation amount along the x-axis
            int translateY = -30; // Translation amount along the y-axis
            double rotateAngle = 0; // Rotation amount in degrees

            // Create an AffineTransform object and apply transformations
            AffineTransform transform = new AffineTransform();
            transform.translate(translateX, translateY);
            transform.scale(scaleX, scaleY);
            transform.rotate(Math.toRadians(rotateAngle), centerX, centerY);

            // Draw the transformed rectangle
            //drawTransformedRectangle(g, centerX - 100, centerY + 100, 200, 200, transform);

            // Draw a transformed regular pentagon
            drawRegularPolygon(g, centerX, centerY - 100, 4, 100, transform);
            //drawRegularPolygon(g, centerX, centerY - 100, 6, 100, transform);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Transform frame = new Transform();
            frame.setVisible(true);
        });
    }
}
