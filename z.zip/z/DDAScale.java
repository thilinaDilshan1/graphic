import javax.swing.*;
import java.awt.*;

public class DDAScale extends JFrame {
    private int centerX, centerY, maxX, maxY;
    private double scaleX, scaleY; // Scaling factors

    public DDAScale() {
        setTitle("DDA Algorithm");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set up the drawing panel
        DrawingPanel drawingPanel = new DrawingPanel();
        add(drawingPanel);

        // Center the frame on the screen
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((screenSize.width - getWidth()) / 2, (screenSize.height - getHeight()) / 2);

        // Set initial scaling factors
        scaleX = 1.0;
        scaleY = 1.0;
    }

    class DrawingPanel extends JPanel {
        public DrawingPanel() {
            setPreferredSize(new Dimension(400, 400));
        }

        private void initgr() {
            Dimension d = getSize();
            maxX = d.width - 1;
            maxY = d.height - 1;
            centerX = maxX / 2;
            centerY = maxY / 2;
        }

        private void drawLine(Graphics g, int x1, int y1, int x2, int y2) {
            double xc, yc;
            double dx, dy, steps, x, y, k;

            dx = x2 - x1;
            dy = y2 - y1;

            if (Math.abs(dx) > Math.abs(dy))
                steps = Math.abs(dx);
            else
                steps = Math.abs(dy);

            xc = (dx / steps);
            yc = (dy / steps);
            x = x1;
            y = y1;

            for (k = 1; k <= steps; k++) {
                x = x + xc;
                y = y + yc;
                g.fillOval((int) (x * scaleX), (int) (y * scaleY), 5, 5);
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            initgr();

            // Set your desired scaling factors
            scaleX = 2.0;
            scaleY = 0.5;

            // Draw scaled lines
            drawLine(g, centerX - 100, centerY + 100, centerX + 100, centerY + 100);
            drawLine(g, centerX + 100, centerY + 100, centerX + 100, centerY - 100);
            drawLine(g, centerX + 100, centerY - 100, centerX - 100, centerY - 100);
            drawLine(g, centerX - 100, centerY - 100, centerX - 100, centerY + 100);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            DDAScale frame = new DDAScale();
            frame.setVisible(true);
        });
    }
}
