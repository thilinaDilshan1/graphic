import javax.swing.*;
import java.awt.*;

public class DDATranslate extends JFrame {
    private int centerX, centerY, maxX, maxY;

    public DDATranslate() {
        setTitle("DDA Algorithm");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set up the drawing panel
        DrawingPanel drawingPanel = new DrawingPanel();
        add(drawingPanel);

        // Center the frame on the screen
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((screenSize.width - getWidth()) / 2, (screenSize.height - getHeight()) / 2);
    }

    class DrawingPanel extends JPanel {
        private int[][] rectangleVertices;

        public DrawingPanel() {
            setPreferredSize(new Dimension(400, 400));
        }

        private void initgr() {
            Dimension d = getSize();
            maxX = d.width - 1;
            maxY = d.height - 1;
            centerX = maxX / 2;
            centerY = maxY / 2;
        }

        private void drawLine(Graphics g, int x1, int y1, int x2, int y2) {
            double xc, yc;
            double dx, dy, steps, x, y, k;

            dx = x2 - x1;
            dy = y2 - y1;

            if (Math.abs(dx) > Math.abs(dy))
                steps = Math.abs(dx);
            else
                steps = Math.abs(dy);

            xc = (dx / steps);
            yc = (dy / steps);
            x = x1;
            y = y1;

            for (k = 1; k <= steps; k++) {
                x = x + xc;
                y = y + yc;
                g.fillOval((int) x, (int) y, 5, 5);
            }
        }

        private void drawRectangle(Graphics g, int[][] vertices) {
            for (int i = 0; i < vertices.length; i++) {
                int nextIndex = (i + 1) % vertices.length;
                drawLine(g, vertices[i][0], vertices[i][1], vertices[nextIndex][0], vertices[nextIndex][1]);
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            initgr();

            rectangleVertices = new int[][] {
                    {centerX - 100, centerY + 100},
                    {centerX + 100, centerY + 100},
                    {centerX + 100, centerY - 100},
                    {centerX - 100, centerY - 100}
            };

            // Translate the rectangle by (30, 20)
            translateRectangle(rectangleVertices, new int[]{30, 20});

            // Translated rectangle
            drawRectangle(g, rectangleVertices);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            DDATranslate frame = new DDATranslate();
            frame.setVisible(true);
        });
    }

    public static void translateRectangle(int P[][], int T[]) {
        for (int i = 0; i < P.length; i++) {
            P[i][0] += T[0]; // Translate x-coordinate
            P[i][1] += T[1]; // Translate y-coordinate
        }
    }
}
